# Serato library interoperability

OpenDecks reads Serato crates today and is being extended to read and write the
Serato on-disk formats directly. This document records what is implemented,
what is planned, and the format rules the implementation must follow.

OpenDecks is independent and not affiliated with or endorsed by Serato. The file
formats below were documented from public community notes. No Serato source
code or assets are used.

## Current support

- Crate import: `src/renderer/media/serato.ts` parses the tagged block format
  (`vrsn`, nested `trak`/`ptrk` blocks, UTF-16LE/BE paths). The parser accepts
  both little- and big-endian path strings, normalises Windows separators and
  `file://` prefixes, de-duplicates by case-insensitive path, and ignores
  unknown blocks.
- The library UI can import one or more `.crate` files and a `database V2`
  export; imported entries are matched to files by path.
- WAV, MP3, AIFF, M4A/AAC, FLAC, Ogg/Opus and WebM are accepted as audio.

Implemented and wired in the Electron shell: crate and `database V2` export,
`neworder.pref`, Serato Markers_ / Markers2 / BeatGrid read/write, the 18-colour
cue palette, an ID3v2.3/2.4 GEOB reader and writer that preserves unrelated
frames, RIFF `id3 ` writing for WAV/AIFF, FLAC `VORBIS_COMMENT` fields, and MP4
freeform atoms. The codecs are tested against tags and a crate written by Serato
DJ Pro 4, plus OpenDecks-generated round-trip fixtures.

Not implemented yet: full playlist and `database V2` read/write, and the opt-in
SQLite column layout edit.

## On-disk layout

A Serato library is a `_Serato_` directory. The relevant parts are:

| Path | Purpose |
| --- | --- |
| `database V2` | Tagged track database: path plus per-track metadata |
| `Subcrates/*.crate` | One file per crate or subcrate |
| `neworder.pref` | Crate ordering |
| `Serato Library.sqlite` (Serato DJ Pro 4) | Current library database |

Serato DJ Pro 4 reads and writes SQLite, but it still exports the legacy
`database V2` / `Subcrates/*.crate` / `neworder.pref` files and imports them
automatically at startup when they changed since it last looked. Writing the
legacy format is therefore enough to create crates that Serato 4 imports.

Crate files are a sequence of big-endian tagged blocks: a four-byte ASCII tag,
a four-byte big-endian payload length, then the payload. Nested blocks are
common (`trak` contains `ptrk`). Paths in `ptrk`/`pfil` are UTF-16 with no
leading BOM; both byte orders occur, so detect from the zero-byte pattern.

## Rules that matter when writing

These are the failure modes observed by other implementations; each one is a
test case for the exporter.

1. The crate header must be exactly `1.0/Serato ScratchLive Crate`. A different
   version string still creates a crate from the file name but silently drops
   its contents.
2. WAV tracks must be typed `wave` in `database V2`, not `wav`.
3. Crate contents are matched to library tracks by path, not by filename or
   index. Re-exporting is safe: existing tracks get the crate attached.
4. Serato must be closed while its files are written. On quit it exports its
   own state over the legacy files.
5. Cue colours are quantised to an 18-value palette; arbitrary RGB is not
   preserved.
6. Cue slots 1-5 are read from legacy `Serato Markers_` in preference to
   `Serato Markers2` by some versions, so write both representations.
7. The beat-grid lock flag must be set when importing an external grid, or
   Serato's analysis replaces it on first load.
8. Crate column layout (`ovct`) only reaches the DJ column set. The per-crate
   view layout lives in Serato's SQLite (`container_asset_list_columns`, usage
   `1`, fields separated by ASCII `0x1e`). Editing that table is a separate,
   opt-in step with a backup, and only valid after Serato has imported the
   crate.

## Tag containers

Cues, loops, beat grid, key and BPM live inside the audio file, not in the
library database:

| Container | Tracks | Frames/atoms |
| --- | --- | --- |
| ID3v2 `GEOB` | MP3, AIFF, WAV | `Serato Markers2`, legacy `Serato Markers_`, `Serato BeatGrid` |
| FLAC `VORBIS_COMMENT` | FLAC | `SERATO_MARKERS_V2`, `SERATO_MARKERS_`, `SERATO_BEATGRID` |
| MP4 atoms | M4A/AAC | `----:com.serato.dj:*` |

The writer follows these constraints:

- Preserve all existing tags and audio payload bytes. Parse, splice the target
  frames, re-serialise the container; never re-encode audio.
- Write to a temporary copy and swap it in only after the non-target bytes are
  verified identical.
- Log the replaced tag bytes so the operation can be undone.
- Refuse to write while Serato is running, and refuse unknown tag versions
  rather than guessing.

## Import precedence

When both `Serato Markers_` and `Serato Markers2` exist, cue slots 1-5 come from
`Markers_` and slots 6-8 from `Markers2` on versions that retain the legacy
frame. OpenDecks reads both and presents one merged view, preferring the legacy
value for slots 1-5.

## Test fixtures

Fixtures must be generated by OpenDecks itself or contributed with a clear
license. Do not commit real Serato library files, artwork or audio. The test
suite builds synthetic crates and tags, round-trips them, and compares bytes
against the documented layout.
